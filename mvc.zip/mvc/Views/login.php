<div class="album py-5 bg-light" style="height:100vh;">
            <div class="row h-100 justify-content-center align-items-center">
                <div class="card border-success" style="max-width: 30rem;padding: 2%;">
                    <h2> Login </h2> <hr>
                    <div class="card-body">
                        <form method="post">
                            <div class="mb-3">
                                <label for="login_email" class="form-label">Email</label>
                                <input type="email" class="form-control" id="login_email" name="email" placeholder="name@example.com">
                            </div>
                            <div class="mb-3">
                                <label for="login_password" class="form-label">Password</label>
                                <input type="password" class="form-control" id="login_password" name="pass" placeholder="password">
                            </div>
                            <div class="mb-3">
                                <input type="submit" name="login" id="login" value="Login" class="btn btn-primary">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>